# Monitoring solutoins on Azure platform

## Reference Architectures

### Log Monitoring

### Metrics Monitoring

## Sample on Kubenetes cluster





