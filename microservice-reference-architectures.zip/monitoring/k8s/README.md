# Kubernetes based microservice monitoring solution on Azure platform.

## Prerequisite

* Azure Cli

## Public Azure

## Azure Mooncake

## References

### [elk-acs-kubernetes](https://github.com/Microsoft/elk-acs-kubernetes) (MIT License)

This repo contains tools that enable user to deploy ELK stack in Kubernetes cluster hosted in Azure Container Service.

### [charts](https://github.com/kubernetes/charts) (Apach-2.0 License)

Use this repository to submit official Charts for Kubernetes Helm. Charts are curated application definitions for Kubernetes Helm. For more information about installing and using Helm, see its README.md. To get a quick introduction to Charts see this chart document.